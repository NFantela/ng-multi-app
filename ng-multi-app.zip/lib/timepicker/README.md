#Timepicker todos
Next do container components for hours and minutes try to do just 1 container for both types

#Bugfixes
Mouseup should work on entire document not just element or created component
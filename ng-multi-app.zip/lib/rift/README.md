#RIFT is simple custom mix of CDK portal and OVERLAY
-- the goal is to create 3 overlay like elements in the DOM
<div class="rift-container">
    <div class="rift-spawns">
        <!-- ELEMENTS GO HERE -->
        <!-- REMEMBER to create backdrop element for clicks -->
    </div>
</div>
=================================================================
# Step 1 Portal like functionality
the first time container 
------------------------------------------------------------------
STAO NA RIFT REF - on mora kreirati komponentu etc kao ša radi overlay - stao na detach
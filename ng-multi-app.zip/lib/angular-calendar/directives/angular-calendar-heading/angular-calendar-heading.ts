import { Directive  } from '@angular/core';


@Directive({
    selector: 'angular-calendar-heading'
})export class AngularCalendarHeadingDirective { }
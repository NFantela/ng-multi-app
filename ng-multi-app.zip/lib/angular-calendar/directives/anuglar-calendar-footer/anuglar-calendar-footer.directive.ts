import { Directive  } from '@angular/core';


@Directive({
    selector: 'angular-calendar-footer'
})export class AngularCalendaFooterDirective { }
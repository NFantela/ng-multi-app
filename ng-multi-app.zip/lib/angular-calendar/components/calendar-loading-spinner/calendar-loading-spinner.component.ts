import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'calendar-loading-spinner',
    styleUrls: ['calendar-loading-spinner.component.scss'],
    templateUrl: 'calendar-loading-spinner.component.html',
    changeDetection:ChangeDetectionStrategy.OnPush
})
export class CalendarLoadingSpinnerComponent {


    
}
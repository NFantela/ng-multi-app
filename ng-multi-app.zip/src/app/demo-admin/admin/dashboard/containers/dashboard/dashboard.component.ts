import { Component } from '@angular/core';

@Component({
    selector: 'admin-dashboard',
    template: `
        <section class="home">
            <article class="panel--centered">
                <dashboard-list></dashboard-list>
            </article>
        </section>
    `
})
export class AdminDashboardComponent {
    constructor() {}
}
import { Component } from '@angular/core';

@Component({
    selector: 'admin-dashboard',
    template: `
        <div>
            Admin dashboard here
        </div>
    `
})
export class AdminDashboardComponent {
    constructor() {}
}
import { Component } from '@angular/core';

@Component({
    selector: 'users',
    template: `
        <div>
           Hello this is users Componnet 
        </div>
    `
})
export class UsersComponent {
    constructor() {}
}
import { Component } from '@angular/core';
import { AngularCalendarDateChange } from 'lib/angular-calendar/containers/angular-calendar/angular-calendar.component';

export class MyCustomCalendarEvent {
    constructor(public somName:string){}
}

@Component({
    selector: 'home',
    templateUrl: 'home.component.html'
})
export class HomeComponent {
    constructor() {}

    handleDateChange(e:AngularCalendarDateChange){
        console.log(e);
    }

    otherStartDate = new Date('December 17, 1995 03:24:00');

    public myEvents = [new MyCustomCalendarEvent('event1'), new MyCustomCalendarEvent('event2')];
}